document.addEventListener('DOMContentLoaded', function() {
    // Contact form AJAX submit to prevent redirect
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(contactForm);
            fetch(contactForm.action, {
                method: 'POST',
                body: formData,
                headers: { 'Accept': 'application/json' }
            })
            .then(response => {
                if (response.ok) {
                    contactForm.reset();
                    document.getElementById('contact-success').style.display = 'block';
                } else {
                    alert('There was a problem sending your message.');
                }
            })
            .catch(() => {
                alert('There was a problem sending your message.');
            });
        });
    }
    const testimonialsGrid = document.querySelector('.testimonials-grid');
    if (!testimonialsGrid) return;
    // Duplicate testimonial cards for seamless infinite marquee, always filling the container
    const parent = testimonialsGrid.parentElement;
    const cards = Array.from(testimonialsGrid.children);
    let gridWidth = testimonialsGrid.scrollWidth;
    let parentWidth = parent.offsetWidth;
    // Keep duplicating until grid is at least 2x parent width (for smoothness)
    while (gridWidth < parentWidth * 2 && cards.length > 0) {
        cards.forEach(card => {
            const clone = card.cloneNode(true);
            clone.classList.add('cloned');
            testimonialsGrid.appendChild(clone);
        });
        gridWidth = testimonialsGrid.scrollWidth;
    }
    testimonialsGrid.addEventListener('mouseover', function(e) {
        if (e.target.closest('.testimonial-card')) {
            testimonialsGrid.classList.add('paused');
        }
    });
    testimonialsGrid.addEventListener('mouseout', function(e) {
        if (e.target.closest('.testimonial-card')) {
            testimonialsGrid.classList.remove('paused');
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {

  const section = document.querySelector('.feature-cards-scroll');
  if (!section) return;
  const cards = Array.from(section.querySelectorAll('.feature-card-scroll-item'));
  let current = 0;
  let isLocked = false;
  let lastTransition = 0;
  const TRANSITION_DELAY = 600; // ms
  const SCROLL_SENSITIVITY = 18000; // px of scroll required to move one card

  function updateCards() {
    cards.forEach((card, i) => {
      card.classList.remove('active', 'prev', 'next');
      if (i === current) card.classList.add('active');
      else if (i < current) card.classList.add('prev');
      else card.classList.add('next');
    });
  }
  updateCards();

  function lockScroll(e) {
    if (!isLocked) return;
    e.preventDefault();
    e.stopPropagation();
    return false;
  }

  function isSectionInView() {
    const rect = section.getBoundingClientRect();
    return rect.top <= 0 && rect.bottom > window.innerHeight/2;
  }

  let lastScrollY = window.scrollY;
  let ticking = false;
  let accumulatedScroll = 0;
  function onScroll() {
    if (!isSectionInView()) {
      isLocked = false;
      accumulatedScroll = 0;
      lastScrollY = window.scrollY;
      return;
    }
    isLocked = true;
    const now = Date.now();
    if (now - lastTransition < TRANSITION_DELAY) {
      lastScrollY = window.scrollY;
      return;
    }
    const delta = window.scrollY - lastScrollY;
    accumulatedScroll += delta;
    if (accumulatedScroll > SCROLL_SENSITIVITY && current < cards.length - 1) {
      current++;
      updateCards();
      window.scrollTo(0, section.offsetTop);
      lastTransition = now;
      accumulatedScroll = 0;
    } else if (accumulatedScroll < -SCROLL_SENSITIVITY && current > 0) {
      current--;
      updateCards();
      window.scrollTo(0, section.offsetTop);
      lastTransition = now;
      accumulatedScroll = 0;
    }
    lastScrollY = window.scrollY;
    if (current === cards.length - 1 && section.getBoundingClientRect().bottom <= window.innerHeight) {
      isLocked = false;
    }
  }

  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(function () {
        onScroll();
        ticking = false;
      });
      ticking = true;
    }
  });
  window.addEventListener('wheel', function (e) {
    if (isLocked) lockScroll(e);
  }, { passive: false });
  window.addEventListener('touchmove', function (e) {
    if (isLocked) lockScroll(e);
  }, { passive: false });
});
// Sticky stacked card animation for feature cards
function stackedFeatureCards() {
  const cards = document.querySelectorAll('.features-grid .feature-card');
  const grid = document.querySelector('.features-grid');
  if (!cards.length || !grid) return;
  const gridRect = grid.getBoundingClientRect();
  let activeIndex = 0;
  cards.forEach((card, i) => {
    const cardRect = card.getBoundingClientRect();
    // Card is active if its top is closest to grid top
    const offset = Math.abs(cardRect.top - gridRect.top);
    if (i === 0 || offset < Math.abs(cards[activeIndex].getBoundingClientRect().top - gridRect.top)) {
      activeIndex = i;
    }
  });
  cards.forEach((card, i) => {
    card.classList.remove('active', 'stacked', 'behind');
    if (i === activeIndex) {
      card.classList.add('active');
    } else if (i === activeIndex + 1) {
      card.classList.add('stacked');
    } else if (i > activeIndex + 1) {
      card.classList.add('behind');
    } else {
      card.classList.add('behind');
    }
  });
}

window.addEventListener('scroll', stackedFeatureCards);
window.addEventListener('DOMContentLoaded', stackedFeatureCards);
// Smooth scrolling function
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

// Add interactive navigation highlighting
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-links a');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove('active'));

            // Add active class to clicked link
            this.classList.add('active');

            // Scroll to section
            const targetId = this.getAttribute('href').substring(1);
            scrollToSection(targetId);
        });
    });
});

// Add scroll effect for navbar
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.background = 'rgba(26, 26, 46, 0.95)';
        navbar.style.backdropFilter = 'blur(10px)';
    } else {
        navbar.style.background = 'linear-gradient(135deg, #1a1a2e, #16213e)';
        navbar.style.backdropFilter = 'none';
    }
});

function revealOnScroll() {
    const fadeEls = document.querySelectorAll('.fade-in-scroll, .animated-section');
    fadeEls.forEach(el => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight - 80) {
            let parentSection = el.closest('.features-section, .stats-section, .games-section, .testimonials-section, .about-section, .contact-section, .game-page-section');
            if (parentSection) {
                parentSection.classList.add('is-visible');
            } else {
                el.classList.add('is-visible');
            }
        } else {
            let parentSection = el.closest('.features-section, .stats-section, .games-section, .testimonials-section, .about-section, .contact-section, .game-page-section');
            if (parentSection && parentSection.classList.contains('features-section')) return;
            el.classList.remove('is-visible');
        }
    });
}

window.addEventListener('scroll', revealOnScroll);
window.addEventListener('DOMContentLoaded', revealOnScroll);

let statsAnimated = false;
function animateStats() {
    if (statsAnimated) return;
    const statsSection = document.querySelector('.stats-section');
    if (!statsSection) return;
    const rect = statsSection.getBoundingClientRect();
    if (rect.top < window.innerHeight - 80) {
        const statNumbers = statsSection.querySelectorAll('.stat-number');
        statNumbers.forEach(numEl => {
            const target = parseInt(numEl.getAttribute('data-target'), 10);
            let current = 0;
            const duration = 2000;
            const startTime = performance.now();
            function update(now) {
                const elapsed = now - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const value = Math.floor(progress * (target - 0));
                numEl.textContent = value;
                if (progress < 1) {
                    requestAnimationFrame(update);
                } else {
                    numEl.textContent = target;
                }
            }
            requestAnimationFrame(update);
        });
        statsAnimated = true;
    }
}


window.addEventListener('scroll', animateStats);
window.addEventListener('DOMContentLoaded', animateStats);